#include "include/gradient_constraint_clock.h"
#include <stdexcept>

void check(bool ok) { if (!ok) throw std::runtime_error("Mapping update clock regression"); }
int main() {
  MappingUpdateClock clock;
  check(!clock.guardReady(false, 0));
  for (int i = 0; i < 999; ++i) clock.record(true, true);
  check(!clock.guardReady(true, 1000));
  clock.record(true, false);  // Gaussian-only update is not TF training.
  clock.record(false, true); // CANCEL/NOOP is not a successful TF update.
  check(clock.tf_updates == 999 && clock.rejected_updates == 1);
  check(clock.gaussianLRStep(1001) == 1000);
  clock.record(true, true);
  check(clock.guardReady(true, 1000) && clock.tf_updates == 1000);
  check(!clock.guardReady(false, 1000));
  clock.record(false, false);
  check(clock.tf_updates == 1000 && clock.gaussianLRStep(1002) == 1000);
  // CD/replay/mapping topology operations never call record().
  check(clock.guardReady(true, 1000));
  clock.tf_updates = 0; // Only creating a new TF resets its warmup clock.
  check(!clock.guardReady(true, 1000));
}
