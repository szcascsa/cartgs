#include "include/gaussian_mapper.h"

#include <chrono>
#include <filesystem>
#include <iostream>
#include <stdexcept>

namespace {
void check(bool ok, const char* message) { if (!ok) throw std::runtime_error(message); }

std::vector<torch::Tensor> snapshot(const std::vector<torch::Tensor>& parameters) {
  std::vector<torch::Tensor> result;
  for (const auto& p : parameters) result.push_back(p.detach().clone());
  return result;
}
bool changed(const std::vector<torch::Tensor>& parameters,
             const std::vector<torch::Tensor>& before) {
  for (std::size_t i = 0; i < parameters.size(); ++i)
    if (!parameters[i].equal(before[i])) return true;
  return false;
}

// Exercise the production KF sampler and Mapping body with real shared Adam.
class RotationMapper : public GaussianMapper {
  static std::filesystem::path selectorConfig(const std::filesystem::path& output) {
    std::filesystem::create_directories(output);
    std::ifstream input(std::filesystem::path(CARTGS_TEST_SOURCE_DIR) / "cfg/selector/fast.yaml");
    check(input.is_open(), "Cannot read existing fast config");
    const auto path = output / "selector_config.yaml";
    std::ofstream fixture(path);
    check(fixture.is_open(), "Cannot write test config");
    const std::map<std::string, std::string> overrides = {
        {"Training.ultra_light_enabled:", "1"}, {"GlobalGI.mode:", "recent"},
        {"Protection.drift_temperature:", "0.1"}};
    for (std::string line; std::getline(input, line);) {
      for (const auto& replacement : overrides)
        if (line.rfind(replacement.first, 0) == 0)
          line = replacement.first + " " + replacement.second;
      fixture << line << '\n';
    }
    return path;
  }
 public:
  explicit RotationMapper(const std::filesystem::path& output)
      : GaussianMapper(nullptr,
          std::filesystem::path(CARTGS_TEST_SOURCE_DIR) / "cfg/gaussian_mapper/RGB-D/TUM/tum_rgbd.yaml",
          output, 0, torch::kCUDA, true,
          selectorConfig(output)) {}

  void verify() {
    const auto opts = torch::TensorOptions().dtype(torch::kFloat32).device(torch::kCUDA);
    auto& model = *gaussians_;
    model.xyz_ = torch::tensor({{-0.1f,0.0f,2.0f},{0.1f,0.0f,2.0f},{0.0f,0.1f,2.1f}}, opts).set_requires_grad(true);
    model.features_dc_ = torch::full({3,1,3}, 0.2f, opts).set_requires_grad(true);
    model.features_rest_ = torch::full({3,15,3}, 0.01f, opts).set_requires_grad(true);
    model.opacity_ = torch::zeros({3,1}, opts).set_requires_grad(true);
    model.scaling_ = torch::full({3,3}, -2.7f, opts).set_requires_grad(true);
    model.rotation_ = torch::tensor({{1.0f,0.0f,0.0f,0.0f}}, opts).repeat({3,1}).set_requires_grad(true);
    model.active_sh_degree_ = default_sh_ = 1;
    model.spatial_lr_scale_ = 1.0f;
    model.max_radii2D_ = torch::zeros({3}, opts);
    model.exist_since_iter_ = torch::zeros({3}, opts.dtype(torch::kInt32));
    model.protection_.reset(3, opts);
    model.protection_.maturity.fill_(1);
    model.protection_.mapping_iteration = 6000;
    model.last_elastic_supervised_iter_ = torch::zeros({3}, opts.dtype(torch::kLong));
    model.Tensor_vec_xyz_ = {model.xyz_}; model.Tensor_vec_feature_dc_ = {model.features_dc_};
    model.Tensor_vec_feature_rest_ = {model.features_rest_}; model.Tensor_vec_opacity_ = {model.opacity_};
    model.Tensor_vec_scaling_ = {model.scaling_}; model.Tensor_vec_rotation_ = {model.rotation_};
    model.trainingSetup(opt_params_);
    recent_window_importance_->resetForGaussianCount(3);
    iteration_ = 6000; mapping_iter_ = 6000;
    scene_->cameras_extent_ = 1.0f;
    do_gaus_pyramid_training_ = false;
    selector_detach_gaussian_parameters_ = true; // Rotation must always override this.
    selector_gi_loss_weight_ = 0.0f;
    selector_replay_enabled_ = false;
    gradient_constraint_config_.enabled = false;
    opt_params_.iterations_ = 10000;
    opt_params_.densify_until_iter_ = -1;
    opt_params_.densify_from_iter_ = 100000;
    opt_params_.opacity_reset_interval_ = 0;
    transform_field_config_.hexplane.spatial_resolution = 4;
    transform_field_config_.hexplane.ratio_resolution = 4;
    transform_field_config_.hexplane.feature_dim = 2;
    transform_field_config_.hexplane.multires = {1};
    transform_field_config_.hidden_dim = 4;
    keyframe_record_interval_ = all_keyframes_record_interval_ = training_report_interval_ = 0;
    {
      torch::NoGradGuard no_grad;
      selector_network_->named_parameters()["soft_net.bias"].copy_(torch::tensor({0.0f,4.0f}, opts));
    }
    initializeTransformFieldIfNeeded();
    ensureSharedMappingOptimizer();

    const std::array<std::size_t, 5> ids = {1,8,3,11,2};
    for (auto id : ids) {
      auto camera = std::make_shared<GaussianKeyframe>(id);
      camera->camera_id_ = 0;
      camera->setPose(Eigen::Quaterniond::Identity(), Eigen::Vector3d::Zero());
      camera->image_height_ = 32; camera->image_width_ = 40;
      camera->FoVx_ = camera->FoVy_ = 1.0f;
      camera->world_view_transform_ = torch::eye(4, opts);
      camera->full_proj_transform_ = camera->getProjectionMatrix(
          0.01f,100.0f,1.0f,1.0f,torch::kCUDA).transpose(0,1).contiguous();
      camera->camera_center_ = torch::zeros({3}, opts);
      camera->original_image_ = torch::full({3,32,40}, 0.1f, opts);
      camera->remaining_times_of_use_ = 1;
      scene_->addKeyframe(camera, &kfid_shuffled_);
    }
    // Map order is 1,2,3,8,11. Each iteration obtains a new sampler result.
    kfid_shuffle_ = {0,3,2,4,1};
    kfid_shuffle_idx_ = 4; kfid_shuffled_ = true;
    for (auto& entry : scene_->keyframes()) entry.second->remaining_times_of_use_ = 0;
    check(useOneRandomSlidingWindowKeyframe() != nullptr && kfs_loss_.empty(),
          "Adaptive sampler failed before the first Full quality estimate");
    for (auto& entry : scene_->keyframes()) entry.second->remaining_times_of_use_ = 1;
    kfid_shuffle_idx_ = 4;
    kfs_used_times_.clear();
    for (std::size_t i = 0; i < ids.size(); ++i) {
      auto camera = useOneRandomSlidingWindowKeyframe();
      check(camera->fid_ == ids[i], "Ratio rotation changed KF sampler results");
      const auto selector_before = snapshot(selector_network_->parameters());
      const auto tf_before = snapshot(transform_field_->parameters());
      const auto gaussian_before = snapshot(model.optimizer_->param_groups()[1].params());
      const auto losses = kfs_loss_;
      const auto ema = ema_loss_for_log_;
      const auto accum = model.xyz_gradient_accum_.clone(), denom = model.denom_.clone();
      const auto radii = model.max_radii2D_.clone();
      const auto topology = topology_version_, tf_steps = normal_update_clock_.tf_updates;
      std::vector<int64_t> adam_steps;
      std::vector<torch::Tensor> moments;
      if (i == 4) {
        for (std::size_t group = 6; group < model.optimizer_->param_groups().size(); ++group)
          for (const auto& p : model.optimizer_->param_groups()[group].params()) {
            const auto found = model.optimizer_->state().find(p.unsafeGetTensorImpl());
            adam_steps.push_back(found == model.optimizer_->state().end() ? 0 :
                static_cast<const torch::optim::AdamParamState&>(*found->second).step());
            moments.push_back(found == model.optimizer_->state().end() ? torch::Tensor() :
                static_cast<const torch::optim::AdamParamState&>(*found->second).exp_avg().clone());
            // A geometry event may leave stale gradients before Full.
            p.mutable_grad() = torch::ones_like(p);
          }
      }
      ++iteration_;
      trainMappingIteration(camera, true, false);
      ++mapping_iter_;
      check(changed(model.optimizer_->param_groups()[1].params(), gaussian_before),
            "Normal render did not update Master Gaussian color");
      check(topology_version_ == topology, "Unexpected topology decision");
      if (i < 4) {
        check(kfs_loss_ == losses && ema_loss_for_log_ == ema, "LOD contaminated KF loss/EMA");
        check(model.xyz_gradient_accum_.equal(accum) && model.denom_.equal(denom) &&
              model.max_radii2D_.equal(radii), "LOD contaminated densification statistics");
        const auto ratio = selector_target_ratios_.at(i);
        const bool tf_executed = continuous_tf_statistics_.ratios.at(ratio).executed > 0;
        check(changed(selector_network_->parameters(), selector_before), "LOD failed to update Selector");
        check(changed(transform_field_->parameters(), tf_before) == tf_executed,
              "TF changed on a skipped branch or failed to update an executed branch");
        check(normal_update_clock_.tf_updates == tf_steps + (tf_executed ? 1 : 0), "LOD TF count wrong");
      } else {
        check(model.protection_.snapshot_valid.all().item<bool>() &&
              !model.protection_.touched_in_cycle.any().item<bool>(),
              "Committed Full failed to create the cycle snapshot/reset touched");
        check(kfs_loss_.size() == 1 && kfs_loss_.count(camera->fid_) == 1,
              "Full did not update KF loss exactly once");
        check((model.denom_ > denom).any().item<bool>(), "Full did not accumulate visibility statistics");
        check(!changed(selector_network_->parameters(), selector_before) &&
              !changed(transform_field_->parameters(), tf_before) &&
              normal_update_clock_.tf_updates == tf_steps, "Full updated Selector/TF");
        std::size_t j = 0;
        for (std::size_t group = 6; group < model.optimizer_->param_groups().size(); ++group)
          for (const auto& p : model.optimizer_->param_groups()[group].params()) {
            const auto found = model.optimizer_->state().find(p.unsafeGetTensorImpl());
            if (adam_steps[j] == 0) check(found == model.optimizer_->state().end(), "Full created auxiliary Adam state");
            else {
              const auto& state = static_cast<const torch::optim::AdamParamState&>(*found->second);
              check(state.step() == adam_steps[j] && state.exp_avg().equal(moments[j]),
                    "Full advanced auxiliary Adam momentum");
            }
            ++j;
          }
      }
    }
    check(ultrafast_rotation_.full_render_count == 1 && ultrafast_rotation_.lod_render_count == 4 &&
          ultrafast_rotation_.selector_updates == 4 &&
          ultrafast_rotation_.tf_updates == continuous_tf_statistics_.ratios.at(.01f).executed +
              continuous_tf_statistics_.ratios.at(.05f).executed + continuous_tf_statistics_.ratios.at(.10f).executed +
              continuous_tf_statistics_.ratios.at(.15f).executed,
          "Five normal mappings did not produce exactly 4 LOD + 1 Full");

    // Ordinary deadlines land on LOD; clone/split/prune wait for Full.
    opt_params_.densify_from_iter_ = 0;
    opt_params_.densification_interval_ = 3;
    opt_params_.densify_grad_threshold_ = 1e6f;
    densify_min_opacity_ = 0.0f;
    const auto topology_before = topology_version_;
    for (int i = 0; i < 5; ++i) {
      auto camera = useOneRandomSlidingWindowKeyframe();
      const auto color_before = model.features_dc_.detach().clone();
      ++iteration_; trainMappingIteration(camera, true, false); ++mapping_iter_;
      if (i < 4) check(topology_version_ == topology_before, "LOD triggered clone/split/prune");
      else check(!model.features_dc_.equal(color_before), "Full topology discarded Gaussian calibration gradients");
    }
    check(topology_version_ > topology_before && !ultrafast_densify_task_.pending,
          "Full missed deferred topology deadline");
    check(model.protection_.drift_initialized.any().item<bool>(),
          "Second committed Full did not observe a touched Full-to-Full drift");

    // No mature points: preserve existing readiness, still render only LOD.
    transform_field_ = nullptr; transform_optimizer_.reset();
    shared_transform_optimizer_configured_ = false;
    transform_field_config_.enabled = false;
    {
      torch::NoGradGuard no_grad;
      model.protection_.maturity.zero_();
      model.protection_.cached_uniform.fill_(1.0f); // Empty admitted compact population.
    }
    const auto renders_before = ultrafast_rotation_.lod_render_count;
    auto camera = useOneRandomSlidingWindowKeyframe();
    ++iteration_; trainMappingIteration(camera, true, false); ++mapping_iter_;
    check(!transform_field_ && ultrafast_rotation_.lod_render_count == renders_before + 1,
          "Unready TF or empty LOD caused a Full fallback");

    // Online end freezes statistics, but the production entry keeps training.
    transform_field_config_.enabled = true;
    model.protection_.maturity.fill_(1);
    model.protection_.cached_uniform.zero_();
    initializeTransformFieldIfNeeded();
    ensureSharedMappingOptimizer();
    markUltrafastOnlineEnd();
    const auto mappings = mapping_iter_, slots = ultrafast_rotation_.step;
    const auto color_before_tail = model.features_dc_.detach().clone();
    const auto tf_before_tail = snapshot(transform_field_->parameters());
    tail_optimization_schedule_.enabled = true;
    tail_optimization_schedule_.steps = 7;
    opt_params_.iterations_ = 1; // Forced tail must bypass the optimizer cap.
    beginForcedTail(getIteration());
    check(hasNormalOptimizationBudget(), "Mode1 forced tail retained the optimizer cap");
    for (int i = 0; i < 9; ++i) trainForOneIteration();
    check(mapping_iter_ == mappings + 7 && ultrafast_rotation_.step == slots + 7 &&
          ultrafast_rotation_.tailSteps() == 7 && tail_optimization_schedule_.completed(mapping_iter_) == 7,
          "Mode1 fixed tail did not execute exactly seven real mappings");
    check(!model.features_dc_.equal(color_before_tail) && changed(transform_field_->parameters(), tf_before_tail),
          "Mode1 tail advanced clocks without Gaussian/TF optimizer updates");
    check(ultrafast_rotation_.online_end_mapping_iteration == mappings &&
          ultrafast_rotation_.online_end_rotation_step == slots, "Tail moved the online snapshot");

    tail_optimization_schedule_ = TailOptimizationSchedule{};
    tail_optimization_schedule_.enabled = true;
    tail_optimization_schedule_.steps = 0;
    beginForcedTail(getIteration());
    const auto zero_mapping = mapping_iter_;
    const auto zero_iteration = getIteration();
    const auto zero_color = model.features_dc_.detach().clone();
    trainForOneIteration();
    check(mapping_iter_ == zero_mapping && getIteration() == zero_iteration && model.features_dc_.equal(zero_color),
          "Mode1 zero-step tail performed training");

    tail_optimization_schedule_ = TailOptimizationSchedule{};
    selector_max_mapping_iterations_ = 0;
    opt_params_.iterations_ = -1;
    for (int i = 0; i < 3; ++i) trainForOneIteration();
    check(mapping_iter_ == zero_mapping + 3 && ultrafast_rotation_.tailSteps() == 10 &&
          !tail_optimization_schedule_.active, "Mode1 legacy tail was blocked by online end");
    reportUltrafastRotation("tail_test");
    std::cout << "PASS: production KF independence, one branch, KF loss/EMA, topology statistics/decisions, "
                 "G/S/TF updates, Full Adam freeze, fixed/zero/legacy mode1 tail, frozen online boundary\n";
  }
};
} // namespace

int main() {
  if (!torch::cuda::is_available()) { std::cout << "SKIP: CUDA unavailable\n"; return 77; }
  const auto output = std::filesystem::temp_directory_path() /
      ("cartgs-ultrafast-test-" + std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
  RotationMapper mapper(output);
  mapper.verify();
}
