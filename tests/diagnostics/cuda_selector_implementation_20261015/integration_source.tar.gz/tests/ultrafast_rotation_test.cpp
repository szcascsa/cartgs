#include "include/ultrafast_rotation.h"
#include "include/ultra_light_schedule.h"
#include <iostream>
#include <stdexcept>

void check(bool value, const char* message) {
  if (!value) throw std::runtime_error(message);
}

int main() {
  UltrafastRotation rotation;
  const std::array<std::size_t, 12> expected = {0,1,2,3,4,0,1,2,3,4,0,1};
  for (auto phase : expected) {
    check(rotation.phase() == phase, "Wrong ratio order");
    check(rotation.full() == (phase == 4), "Wrong Full phase");
    check(rotation.ratio() == (phase == 4 ? 1.0f : UltrafastRotation::ratios[phase]), "Wrong ratio");
    // Auxiliary work and KF selection do not complete a slot.
    check(rotation.phase() == phase, "Auxiliary work consumed a slot");
    rotation.complete(phase + 1.0, 0.5, true, phase != 4, phase != 4);
    check(rotation.balanced(), "Unbalanced phase counts");
  }
  check(rotation.step == 12 && rotation.full_render_count == 2 &&
        rotation.lod_render_count == 10, "Wrong render counts");
  check(rotation.p95() == 5.0, "Wrong nearest-rank P95");

  rotation.endOnline(12);
  rotation.endOnline(999);
  check(rotation.online_end_mapping_iteration == 12 && rotation.tailSteps() == 0,
        "Online boundary changed");
  const auto online_selector = rotation.online_end_selector_updates;
  const auto online_tf = rotation.online_end_tf_updates;
  for (int i = 0; i < 7; ++i) {
    const auto phase = rotation.phase();
    rotation.complete(1.0, .5, true, phase != 4, phase != 4);
    check(rotation.balanced(), "Tail changed ratio rotation");
  }
  check(rotation.tailSteps() == 7 && rotation.online_end_rotation_step == 12 &&
        rotation.online_end_selector_updates == online_selector && rotation.online_end_tf_updates == online_tf,
        "Tail moved the frozen online boundary/counters");

  // A deadline falling on LOD is executed at the next Full, on the original clock.
  DeferredMappingTask topology;
  for (std::uint64_t iteration = 1; iteration <= 5; ++iteration) {
    topology.observe(iteration, 3);
    check(topology.take(iteration == 5) == (iteration == 5), "Topology escaped Full phase");
  }
  std::cout << "PASS: ratio rotation, counters, P95, online boundary, tail continuation, topology deadline\n";
}
