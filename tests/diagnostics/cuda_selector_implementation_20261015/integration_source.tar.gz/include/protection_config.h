#pragma once
#include <cmath>
#include <stdexcept>

struct ProtectionConfig {
  float drift_temperature = 0.10f;
  float beta_fast = 0.60f;
  float beta_slow = 0.15f;
  float maturity_rise_rate = 0.05f;
  float maturity_fall_rate = 0.50f;
  bool maturity_diagnostics = true;
  // ChangeDistill/historical recovery compatibility only; never a TF/GI/Selector gate.
  float compatibility_mature_threshold = 0.80f;
  bool performance_logging = true;
  void validate() const {
    if (!std::isfinite(drift_temperature) || drift_temperature <= 0 ||
        !std::isfinite(beta_fast) || !std::isfinite(beta_slow) ||
        beta_slow <= 0 || beta_fast > 1 || beta_fast <= beta_slow ||
        !std::isfinite(maturity_rise_rate) || !std::isfinite(maturity_fall_rate) ||
        maturity_rise_rate <= 0 || maturity_fall_rate > 1 || maturity_fall_rate < maturity_rise_rate ||
        !std::isfinite(compatibility_mature_threshold) ||
        compatibility_mature_threshold < 0 || compatibility_mature_threshold > 1)
      throw std::invalid_argument("Invalid continuous geometric maturity configuration");
  }
};
