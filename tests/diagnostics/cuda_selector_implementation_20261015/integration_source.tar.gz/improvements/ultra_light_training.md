# 超轻量在线训练

在 `cfg/selector/fast.yaml` 中开启：

```yaml
Training.ultra_light_enabled: 1
Training.ultra_light_interval: 20
```

默认开关为 `0`，缺少配置项时保持现有行为。间隔必须大于零，`1` 表示每次执行。
此调度只在 ORB-SLAM 在线时生效，无 SLAM 的训练不降频。

## 执行范围

每次有效 Mapping 均执行完整 Gaussian 渲染、loss、反传和更新。SH、学习率、
densify/prune、opacity reset、Mapping 总预算保持原时钟和执行顺序。

SLAM 在线时，第 20、40、60……次有效 Mapping 执行增强逻辑：

- SGI Bank 快照、CPU 选帧、增量贡献；Recent GI 模式则收集正常渲染的贡献。
- Selector、LOD、TF loss 与反传；GradientGuard 按其原配置执行。
- 到期的 SGI 全量刷新、Replay、周期 AABB、历史检测/DSD。

其余步直接提交 Gaussian 更新；Selector/TF 梯度设为 undefined，使共享 Adam
跳过这些参数及其动量、step。Selector、TF、Guard 的调用和实际更新计数不伪增。

关键帧登记、Gaussian 可见次数和 append/prune 缓存对齐仍即时维护。
回环、BA 触发的 geometry transport 和 ChangeDistill 保持即时执行，普通步也
可能有该事件处理开销；事件的蒸馏参数和接受条件不变。

## 时钟与周期任务

`mapping_iter_` 每次有效普通 Mapping 递增一次，普通步和增强步都计入。
Replay、CD、DSD 不推进该时钟。不存在新的增强步调度时钟。

- SGI refresh、AABB check、Replay interval、DSD probe、TF start_iter、
  reference age/horizon 等原来使用 `mapping_iter_` 的操作继续使用它。
- Gaussian 的 `iteration_` 与既有拒绝更新修正、Selector 的更新计数、TF 的
  实际正常更新计数保持原语义，TF 预热和学习率不会被普通步推进。
- 到期的任务被普通步跳过时保留待执行状态，在下一增强步合并执行一次。
  下个到期点仍按原 Mapping 周期计算。例如增强间隔 `7`、刷新间隔 `1000`
  时，到期点为 1000、2000，执行点为 1001、2002，不会变成 7000、14000。
- Replay 保留原本在 Mapping 开始前检查已完成 `mapping_iter_` 的顺序。

以实际 `pSLAM_->isShutDown()` 判断阶段，不使用可能因 Mapping 预算耗尽而
设置的 `SLAM_ended_`。在线结束后的下一次 Mapping 恢复每步增强逻辑，并在
Replay/LOD 前更新 Bank、全量刷新 SGI；本次 Mapping 后额外检查一次 AABB。
在线 LOD 的半分辨率设置仍在 SLAM 结束后恢复原图分辨率。
未开启 [强制覆写尾优化](tail_optimization.md) 时，`Selector.max_mapping_iterations`
仍是总 Mapping 上限；在线期间先耗尽预算时，按原策略结束。开启尾优化覆写后，
忽略该项，在线运行到 SLAM 结束，再执行独立的尾部 Mapping 预算。

在线 Selector/TF 更新频率降低会延长收敛与 Guard 预热，普通步没有历史梯度
保护。总加速幅度仍取决于完整 Gaussian 训练和即时几何事件的成本。

## 可观测性与验证

开启模式后，仅在 SLAM 阶段切换、每 1000 次 Mapping 和保存模型时打印
`[TrainingSchedule]`，包含 `online_basic`、`online_enhanced`、`post_slam`。
SGI 摘要增加 `global_gi_bank_update_count`，用于确认普通步没有 Bank 快照。
导出的 `selector_config.yaml` 保存两个配置项，`transform_state.json` 保存
三类 Mapping 计数。原有 `GlobalGI.verbose_logging: 0` 保持生效。

回归测试覆盖 20/1 步调度、关闭模式、SLAM 结束、非整除周期、待执行任务，
以及普通步不改变 Selector/TF Adam 参数、动量和 step。SGI、DSD 测试覆盖
延后执行仍使用真实 Mapping 时钟、拓扑有效性、Teacher 年龄和几何事件保护。

编译与真实数据验证使用服务器 `/home/prmi/zwj/mycartgs/`；本地不编译。

## 服务器验证结果

CUDA 11.8 / sm_86 / LibTorch 构建完成，29/29 项 CTest 通过，用时 13.09 秒。
包含调度/共享 Adam、SGI、DSD、ChangeDistill、GradientConstraint、拓扑与 CUDA
只读渲染等回归测试。配置静态检查确认已有 120 项参数未修改，仅新增两个开关字段。

真实 Replica room0 前 120 帧，三组均完成 1200 次 Mapping 并正常退出：

| 模式 | 在线普通步 | 在线增强步 | SLAM 后增强步 | Bank 更新次数 |
|---|---:|---:|---:|---:|
| 开启，间隔 20 | 304 | 16 | 880 | 896 |
| 开启，间隔 7 | 205 | 34 | 961 | 995 |
| 关闭 | — | 每步执行 | 每步执行 | 1200 |

20 步模式在线总数为 320，增强步严格为 320/20=16；后续 880 步全部增强。
7 步模式在线总数为 239，增强步严格为 floor(239/7)=34。普通步均不进行
Bank 快照，退出时 SGI invalid 均为 0，配置导出保留开关和间隔。

7 步模式额外开启 DSD，以 113 步 probe 周期验证延后执行：113、226 到期，
119、231 执行；进入 SLAM 后阶段恢复 339、452……等原 Mapping 周期。
AABB 周期为 101，在线到期 101、202 分别在 105、203 执行，之后恢复原周期。
TF start_iter 测试设为 100：20/7 步组分别在已完成 Mapping 119/104 时初始化，
没有按增强执行次数放大到 2000/700。标准 fast 参数仍保持 start_iter=3000。

短测仅调整验证配置的 Mapping 上限、TF 启动和周期检查参数；没有改动用户
fast 中的训练参数。这些运行用于行为验证，不作为训练质量或公平加速比结论。
短测中的几何事件为 AABB；回环/BA 即时处理边界通过未改动的调用链及相关
回归测试检查，没有把这次短测描述为真实回环覆盖。

服务器日志、命令、配置、模型状态与源文件备份：
`/home/prmi/zwj/mycartgs/build-cuda118-sm86-ultra-light-validation/`。
