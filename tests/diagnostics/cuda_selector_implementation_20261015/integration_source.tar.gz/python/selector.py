"""Selector inference helpers shared by the LOD evaluation script."""

import os

import numpy as np
import torch
from torch import nn
from plyfile import PlyData
from elastic_budget import classify_protection, protection_statistics
from elastic_entry import elastic_selector_probability


class SelectorNetwork(nn.Module):
    """Python counterpart of improvements::selector::GumbelNetwork."""

    embedding_width = 32

    def __init__(self):
        super().__init__()
        self.selector_backend = "legacy"
        self.pos_emd = self._make_embedding(3)
        self.rotation_emd = self._make_embedding(4)
        self.scale_emd = self._make_embedding(3)
        self.time_emd = self._make_embedding(1)
        self.soft_net = nn.Linear(self.embedding_width * 4, 2)

    @classmethod
    def _make_embedding(cls, input_width):
        return nn.Sequential(
            nn.Linear(input_width, cls.embedding_width),
            nn.ReLU(),
            nn.Linear(cls.embedding_width, cls.embedding_width),
            nn.ReLU(),
        )

    def forward(self, position, rotation, scale, target_ratio, tau=1.0):
        if self.selector_backend == "cuda":
            from selector_cuda_backend import network
            logits = network((position, rotation, scale, target_ratio), self.parameters())
            return torch.softmax(logits / tau, dim=1)[:, 1]
        features = torch.cat(
            (
                self.pos_emd(position),
                self.rotation_emd(rotation),
                self.scale_emd(scale),
                self.time_emd(target_ratio),
            ),
            dim=1,
        )
        logits = self.soft_net(features)
        return torch.softmax(logits / tau, dim=1)[:, 1]

    def set_backend(self, backend):
        if backend not in ("legacy", "cuda"):
            raise ValueError("Selector.backend must be legacy or cuda")
        if backend == "cuda" and os.environ.get("CARTGS_EXPERIMENTAL_SELECTOR_CUDA") != "1":
            raise RuntimeError("CUDA Selector has not passed production acceptance")
        self.selector_backend = backend


def load_selector(path, device):
    """Load a selector checkpoint produced by the C++ or Python path."""
    if not os.path.isfile(path):
        raise FileNotFoundError("selector checkpoint not found: {}".format(path))

    model = SelectorNetwork().to(device)
    try:
        payload = torch.jit.load(path, map_location=device).state_dict()
    except RuntimeError:
        payload = torch.load(path, map_location=device)
    if isinstance(payload, dict) and "state_dict" in payload:
        payload = payload["state_dict"]
    if not isinstance(payload, dict):
        raise RuntimeError(
            "selector.pt does not contain a readable selector checkpoint."
        )

    state = {}
    for key, value in payload.items():
        key = key.replace("module.", "", 1) if key.startswith("module.") else key
        state[key] = value
    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing or unexpected:
        raise RuntimeError(
            "selector checkpoint keys do not match the selector network: "
            "missing={}, unexpected={}".format(missing, unexpected)
        )
    model.eval()
    return model


def load_selector_metadata(path, device):
    """Load convergence state and saved per-row Bernoulli uniforms."""
    ply = PlyData.read(path)
    vertex = ply["vertex"]
    comments = dict(line.split(" ", 1) for line in ply.comments if " " in line)
    if comments.get("protection_schema") != "continuous_cycle_geometric":
        raise RuntimeError("checkpoint requires continuous_cycle_geometric maturity metadata")
    metadata = {name: torch.as_tensor(
        np.asarray(vertex[name], dtype=np.float32).copy(), device=device)
        for name in ("maturity", "drift_ema", "cached_uniform")}
    for name, value in metadata.items():
        if not torch.isfinite(value).all():
            raise ValueError("non-finite maturity checkpoint field: "+name)
    if ((metadata["maturity"] < 0).any() or (metadata["maturity"] > 1).any()
            or (metadata["drift_ema"] < 0).any()
            or (metadata["cached_uniform"] < 0).any()
            or (metadata["cached_uniform"] >= 1).any()):
        raise ValueError("maturity checkpoint field outside its domain")
    metadata["mapping_iteration"] = int(comments["protection_mapping_iteration"])
    return metadata

@torch.no_grad()
def build_selector_mask(model, gaussians, metadata, ratio, config, temperature=1.0,
                        protection_enabled=True):
    """All-row continuous handoff with the same saved uniforms as C++."""
    total = gaussians.get_xyz.shape[0]
    if metadata is None or any(metadata[k].numel() != total for k in
                               ("maturity", "drift_ema", "cached_uniform")):
        raise RuntimeError("continuous maturity metadata must match Gaussian count")
    c = classify_protection(metadata, config, protection_enabled)
    target_ratio = torch.full((total, 1), float(ratio),
                              dtype=torch.float32, device=gaussians.get_xyz.device)
    entry = config.get("entry_maturity", 0.0)
    def forward(rows):
        if rows is None:
            return model(gaussians.get_xyz, gaussians.get_rotation, gaussians.get_scaling, target_ratio, tau=temperature)
        return model(gaussians.get_xyz[rows], gaussians.get_rotation[rows], gaussians.get_scaling[rows],
                     target_ratio[rows], tau=temperature)
    probability = elastic_selector_probability(metadata["maturity"], c["maturity"], ratio, entry, forward)
    mask = metadata["cached_uniform"] < probability
    active, target = int(mask.sum().item()), ratio*total
    stats = protection_statistics(metadata, c)
    stats.update(target_active=target, expected_active=float(probability.sum().item()),
        actual_active=active, active_gaussians=active,
        actual_vs_target=active/max(1.0, target), ratio=float(ratio),
        protection_enabled=bool(protection_enabled),
        current_mapping_iteration=metadata["mapping_iteration"])
    eligible = int((metadata["maturity"] >= entry).sum().item())
    stats.update(elastic_entry_threshold=entry, elastic_eligible_count=eligible,
        elastic_eligible_fraction=eligible/max(1,total), selector_candidate_count=eligible,
        selector_skipped_low_maturity_count=total-eligible,
        maturity_below_0_3_fraction=float((metadata["maturity"] < .3).float().mean().item()),
        maturity_above_equal_0_3_fraction=float((metadata["maturity"] >= .3).float().mean().item()))
    return mask.float(), stats
