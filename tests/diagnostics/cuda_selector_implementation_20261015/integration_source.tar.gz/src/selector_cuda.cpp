#include "include/selector_cuda.h"
#include <torch/csrc/autograd/custom_function.h>

namespace selector_cuda {
namespace {
class NetworkFunction : public torch::autograd::Function<NetworkFunction> {
 public:
  static torch::Tensor forward(torch::autograd::AutogradContext* ctx,
                               at::TensorList tensors, int64_t candidate) {
    auto in=tensors.vec();
    TORCH_CHECK(in.size()==22,"Selector expects four inputs and eighteen parameters");
    auto stages=selector_cuda::forward({in.begin(),in.begin()+4},
        {in.begin()+4,in.end()},static_cast<Candidate>(candidate));
    in.insert(in.end(),stages.begin(),stages.begin()+8);
    if(stages.size()>9)in.push_back(stages[9]); // Strict final GEMM's packed input.
    ctx->save_for_backward(in);
    return stages[8];
  }
  static torch::autograd::variable_list backward(torch::autograd::AutogradContext* ctx,
                                                torch::autograd::variable_list gradients) {
    auto saved=ctx->get_saved_variables();
    auto result=selector_cuda::backward({saved.begin(),saved.begin()+4},
        {saved.begin()+4,saved.begin()+22},{saved.begin()+22,saved.end()},gradients[0].contiguous());
    result.push_back(torch::Tensor()); // Candidate enum has no gradient.
    return result;
  }
};
}  // namespace

torch::Tensor network(const std::vector<torch::Tensor>& inputs,
    const std::vector<torch::Tensor>& parameters, Candidate candidate) {
  std::vector<torch::Tensor> tensors=inputs;
  tensors.insert(tensors.end(),parameters.begin(),parameters.end());
  return NetworkFunction::apply(at::TensorList(tensors),static_cast<int64_t>(candidate));
}
}  // namespace selector_cuda
