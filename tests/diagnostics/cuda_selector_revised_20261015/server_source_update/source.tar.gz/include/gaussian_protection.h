#pragma once
#include "protection_config.h"
#include "protection_profiler.h"
#include "maturity_dynamics.h"
#include "gaussian_transform_ops.h"
#include <torch/torch.h>
#include <map>

// Online convergence state. Only committed mode-1 Full boundaries observe drift.
class GaussianProtection {
 public:
  ProtectionConfig config;
  int64_t mapping_iteration = 0;  // Logging/supervision clock, not maturity evidence.
  int64_t first_valid_maturity_cycle_iteration = -1;
  torch::Tensor maturity, drift_ema;
  torch::Tensor prev_full_xyz, prev_full_log_scale, prev_full_rotation;
  torch::Tensor snapshot_valid, touched_in_cycle, cached_uniform;
  // First-drift validity is independent of EMA=0 and exp underflow to maturity=0.
  torch::Tensor drift_initialized;
  MaturityDynamics dynamics;
  std::shared_ptr<ProtectionProfiler> profiler = std::make_shared<ProtectionProfiler>();
  ProtectionProfiler* timing() const { return config.performance_logging ? profiler.get() : nullptr; }
  // GPU row indices are reused between maturity/topology changes. Tensor
  // identity/version also catches in-place changes made by checkpoint/tests.
  const torch::Tensor& indicesAbove(float threshold) const {
    torch::NoGradGuard guard;
    if (!entry_cache_source_.defined() || !entry_cache_source_.is_same(maturity) ||
        entry_cache_version_ != maturity._version()) {
      entry_indices_.clear(); entry_cache_source_ = maturity;
      entry_cache_version_ = maturity._version();
    }
    auto found = entry_indices_.find(threshold);
    if (found == entry_indices_.end())
      found = entry_indices_.emplace(threshold,
          torch::nonzero(maturity >= threshold).reshape({-1})).first;
    return found->second;
  }

  void reset(int64_t count, const torch::TensorOptions& options) {
    torch::NoGradGuard guard;
    config.validate();
    first_valid_maturity_cycle_iteration = -1;
    entry_indices_.clear(); entry_cache_source_ = torch::Tensor{};
    const auto floats = options.dtype(torch::kFloat32).requires_grad(false);
    const auto bools = floats.dtype(torch::kBool);
    maturity = torch::zeros({count}, floats);
    drift_ema = torch::zeros({count}, floats);
    prev_full_xyz = torch::zeros({count, 3}, floats);
    prev_full_log_scale = torch::zeros({count, 3}, floats);
    prev_full_rotation = torch::zeros({count, 4}, floats);
    snapshot_valid = torch::zeros({count}, bools);
    touched_in_cycle = torch::zeros({count}, bools);
    drift_initialized = torch::zeros({count}, bools);
    cached_uniform = torch::rand({count}, floats);
    dynamics.enabled = config.maturity_diagnostics;
    dynamics.reset(count, floats, mapping_iteration);
  }
  void assertAligned(int64_t count) const {
    for (const auto& t : {maturity, drift_ema, cached_uniform, snapshot_valid, touched_in_cycle, drift_initialized})
      TORCH_CHECK(t.dim() == 1 && t.numel() == count && t.device() == maturity.device() &&
          !t.requires_grad(), "Maturity state is not Gaussian-topology aligned");
    for (const auto& t : {maturity, drift_ema, cached_uniform, prev_full_xyz, prev_full_log_scale, prev_full_rotation})
      TORCH_CHECK(t.scalar_type() == torch::kFloat32, "Maturity geometry must be FP32");
    for (const auto& t : {snapshot_valid, touched_in_cycle, drift_initialized})
      TORCH_CHECK(t.scalar_type() == torch::kBool, "Maturity validity must be bool");
    for (const auto& t : {prev_full_xyz, prev_full_log_scale, prev_full_rotation})
      TORCH_CHECK(t.dim() == 2 && t.size(0) == count && t.device() == maturity.device() &&
          !t.requires_grad(), "Full snapshot is not Gaussian-topology aligned");
    TORCH_CHECK(prev_full_xyz.size(1) == 3 && prev_full_log_scale.size(1) == 3 &&
        prev_full_rotation.size(1) == 4, "Invalid Full snapshot shape");
    if (dynamics.enabled)
      TORCH_CHECK(dynamics.state.size(0) == count && dynamics.values.size(0) == count &&
          dynamics.state.device() == maturity.device(), "Maturity diagnostics topology mismatch");
  }
  void append(int64_t count, const torch::Tensor& parents = {}) {
    torch::NoGradGuard guard;
    const auto inherit = [&](const torch::Tensor& value) {
      return parents.defined() ? value.index_select(0, parents) : torch::zeros({count}, value.options());
    };
    if (parents.defined()) TORCH_CHECK(parents.numel() == count, "Maturity parent mapping size mismatch");
    maturity = torch::cat({maturity, inherit(maturity)});
    drift_ema = torch::cat({drift_ema, inherit(drift_ema)});
    drift_initialized = torch::cat({drift_initialized, inherit(drift_initialized)});
    prev_full_xyz = torch::cat({prev_full_xyz, torch::zeros({count, 3}, prev_full_xyz.options())});
    prev_full_log_scale = torch::cat({prev_full_log_scale, torch::zeros({count, 3}, prev_full_log_scale.options())});
    prev_full_rotation = torch::cat({prev_full_rotation, torch::zeros({count, 4}, prev_full_rotation.options())});
    snapshot_valid = torch::cat({snapshot_valid, torch::zeros({count}, snapshot_valid.options())});
    touched_in_cycle = torch::cat({touched_in_cycle, torch::zeros({count}, touched_in_cycle.options())});
    cached_uniform = torch::cat({cached_uniform, torch::rand({count}, cached_uniform.options())});
    dynamics.append(count, mapping_iteration, maturity.slice(0, maturity.numel()-count), parents.defined());
    assertAligned(maturity.numel());
  }
  void prune(const torch::Tensor& survivors) {
    torch::NoGradGuard guard;
    assertAligned(survivors.numel());
    dynamics.prune(survivors, maturity);
    for (auto* t : {&maturity, &drift_ema, &prev_full_xyz, &prev_full_log_scale, &prev_full_rotation,
                   &snapshot_valid, &touched_in_cycle, &drift_initialized, &cached_uniform})
      *t = t->index({survivors});
    assertAligned(maturity.numel());
  }
  torch::Tensor selectionMaturity(bool enabled) const {
    return enabled ? maturity.detach() : torch::ones_like(maturity);
  }
  torch::Tensor matureMask() const { return maturity >= config.compatibility_mature_threshold; }
  void markTouched(const torch::Tensor& indices) {
    torch::NoGradGuard guard;
    if (indices.defined() && indices.numel()) touched_in_cycle.index_fill_(0, indices, true);
  }
  void observeFull(const torch::Tensor& xyz, const torch::Tensor& log_scale,
                   const torch::Tensor& normalized_rotation) {
    torch::NoGradGuard guard;
    assertAligned(xyz.size(0));
    if (!xyz.size(0)) return;
    const auto previous = dynamics.enabled ? maturity.clone() : torch::Tensor{};
    torch::Tensor valid, stability, drift;
    {
      ProtectionProfiler::Scope timing_scope(timing(), ProtectionProfiler::MaturityUpdate, xyz.is_cuda());
      // exp(mean(log(s))) == cbrt(sx*sy*sz), avoiding intermediate overflow.
      const auto size = prev_full_log_scale.mean(1).exp().clamp_min(1e-8);
      const auto d_xyz = (xyz - prev_full_xyz).norm(2, 1) / size;
      const auto d_scale = (log_scale - prev_full_log_scale).square().mean(1).sqrt();
      const auto q0 = torch::nn::functional::normalize(prev_full_rotation);
      const auto dot = (q0 * normalized_rotation).sum(1).abs().clamp(0, 1);
      const auto d_rot = (1 - dot.square()).clamp_min(0).sqrt();
      drift = torch::maximum(torch::maximum(d_xyz, d_scale), d_rot);
      valid = touched_in_cycle & snapshot_valid & torch::isfinite(drift);
      // One startup observation, never a per-LoD synchronization for TF cutoff.
      if (first_valid_maturity_cycle_iteration < 0 && valid.any().item<bool>())
        first_valid_maturity_cycle_iteration = mapping_iteration;
      const auto beta = torch::where(drift > drift_ema, config.beta_fast, config.beta_slow);
      const auto next = torch::where(drift_initialized, drift_ema + beta * (drift - drift_ema), drift);
      drift_ema.copy_(torch::where(valid, next, drift_ema));
      stability = (-drift_ema / config.drift_temperature).exp().clamp(0, 1);
      maturity.copy_(torch::where(valid, temporalMaturity(maturity, stability,
          config.maturity_rise_rate, config.maturity_fall_rate), maturity));
      drift_initialized.logical_or_(valid);
    }
    {
      ProtectionProfiler::Scope timing_scope(timing(), ProtectionProfiler::MaturitySnapshot, xyz.is_cuda());
      prev_full_xyz.copy_(xyz.detach());
      prev_full_log_scale.copy_(log_scale.detach());
      prev_full_rotation.copy_(normalized_rotation.detach());
      snapshot_valid.copy_(torch::isfinite(xyz).all(1) & torch::isfinite(log_scale).all(1) &
                           torch::isfinite(normalized_rotation).all(1));
    }
    {
      ProtectionProfiler::Scope diagnostic_scope(timing(), ProtectionProfiler::MaturityDiagnostics, xyz.is_cuda());
      dynamics.observe(mapping_iteration, valid, touched_in_cycle, snapshot_valid,
          drift_initialized, drift, drift_ema, stability, previous, maturity);
    }
    touched_in_cycle.zero_();
  }
  void transportSnapshot(const GaussianTransformResult& correction) {
    torch::NoGradGuard guard;
    if (!correction.changed_attributes) return;
    assertAligned(correction.population_count);
    GaussianAttrState state{prev_full_xyz, prev_full_log_scale, prev_full_rotation};
    if (!correction.affects_all) state = state.select(correction.indices);
    const auto transformed = applyGaussianTransform(state, correction);
    if (correction.affects_all) {
      prev_full_xyz.copy_(transformed.xyz);
      prev_full_log_scale.copy_(transformed.log_scaling);
      prev_full_rotation.copy_(transformed.rotation);
    } else {
      prev_full_xyz.index_copy_(0, correction.indices, transformed.xyz);
      prev_full_log_scale.index_copy_(0, correction.indices, transformed.log_scaling);
      prev_full_rotation.index_copy_(0, correction.indices, transformed.rotation);
    }
  }
  double metadataMB() const {
    int64_t bytes = 0;
    for (const auto& t : {maturity, drift_ema, prev_full_xyz, prev_full_log_scale, prev_full_rotation,
                         snapshot_valid, touched_in_cycle, drift_initialized, cached_uniform})
      bytes += t.numel() * t.element_size();
    return bytes / 1048576.0 + dynamics.memoryMB();
  }
  std::map<std::string, double> statistics(bool enabled = true) const {
    torch::NoGradGuard guard;
    const auto m = selectionMaturity(enabled);
    std::map<std::string, double> result{{"total_gaussians", double(m.numel())}};
    const auto distribution = [&](const torch::Tensor& t, const std::string& prefix,
                                  const std::vector<double>& percentiles) {
      result[prefix + "_mean"] = t.numel() ? t.mean().item<double>() : 0;
      for (const auto q : percentiles)
        result[prefix + "_p" + std::to_string(int(q * 100))] = t.numel() ? torch::quantile(t, q).item<double>() : 0;
      result[prefix + "_median"] = result[prefix + "_p50"];
    };
    distribution(m, "maturity", {.1, .5, .9});
    distribution(drift_ema, "drift", {.5, .9, .95});
    result["snapshot_valid_count"] = snapshot_valid.sum().item<double>();
    result["touched_this_cycle_count"] = touched_in_cycle.sum().item<double>();
    result["compatibility_mature_count"] = (m >= config.compatibility_mature_threshold).sum().item<double>();
    result["maturity_below_0_3_fraction"] = maturity.numel() ? (maturity < .3f).to(torch::kFloat32).mean().item<double>() : 0;
    result["maturity_above_equal_0_3_fraction"] = maturity.numel() ? (maturity >= .3f).to(torch::kFloat32).mean().item<double>() : 0;
    for (int i = 0; i < 5; ++i)
      result["maturity_bucket_" + std::to_string(i)] =
          ((m >= i * .2f) & (i == 4 ? m <= 1 : m < (i + 1) * .2f)).sum().item<double>();
    return result;
  }
  void report(std::ostream& out, bool enabled = true) const {
    out << "[Protection MATURITY] schema=continuous_cycle_geometric mapping_iter=" << mapping_iteration
        << " compatibility_threshold=" << config.compatibility_mature_threshold;
    for (const auto& entry : statistics(enabled)) out << ' ' << entry.first << '=' << entry.second;
    out << '\n';
    if (config.performance_logging) profiler->report(out, metadataMB());
  }
 private:
  mutable torch::Tensor entry_cache_source_;
  mutable int64_t entry_cache_version_ = -1;
  mutable std::map<float, torch::Tensor> entry_indices_;
};
