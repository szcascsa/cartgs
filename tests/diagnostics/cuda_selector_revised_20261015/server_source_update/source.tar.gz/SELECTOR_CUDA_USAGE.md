# Selector backend 切换与手动编译

`cuda-selector` 分支保留两个 backend。当前默认是 `legacy`；CUDA 的真实输入数值、梯度和受控训练测试已通过，完整质量验收尚未完成。

## 编译

在 `/home/prmi/zwj/mycartgs`，使用 `zwj` conda 环境、CUDA 11.8、GCC 9 和 sm86。

已有 `build-deploy-20261015` 的依赖配置可直接复用：

```bash
conda activate zwj
cd /home/prmi/zwj/mycartgs
export PATH=/home/prmi/.local/bin:/usr/local/cuda-11.8/bin:$PATH
export LD_LIBRARY_PATH="$PWD/lib:$PWD/third_party/libtorch-cu118/libtorch/lib:/usr/local/cuda-11.8/lib64:${LD_LIBRARY_PATH:-}"
/home/prmi/.local/lib/python3.13/site-packages/cmake/data/bin/cmake \
  -S . -B build-deploy-20261015 -DCARTGS_EXPERIMENTAL_SELECTOR_CUDA=ON
/home/prmi/.local/lib/python3.13/site-packages/cmake/data/bin/cmake \
  --build build-deploy-20261015 -j2 --target tum_rgbd
```

也可以走完整依赖构建脚本：

```bash
CARTGS_EXPERIMENTAL_SELECTOR_CUDA=ON bash build.sh
```

编译一次后，同一个 binary 可以通过 YAML 在两种 backend 间切换。未打开 CMake 开关的 binary 只能运行 legacy；配置为 cuda 时会明确报错。

## 运行配置

编辑实际传给 `--selector-config` 的文件，例如 `cfg/selector/fast.yaml`：

```yaml
Selector.enabled: 1
Selector.backend: "legacy"  # 改为 "cuda" 即启用 CUDA backend
```

运行参数仍使用：

```bash
... --selector-config /home/prmi/zwj/mycartgs/cfg/selector/fast.yaml
```

启动日志应显示 `[Gaussian Mapper] selector_backend=legacy` 或 `selector_backend=cuda`。配置保存时也会保存该字段。Selector 和 TransformField 的 backend 分别配置；本次没有修改已有 TF、Protection、GI、Replay、CD、DSD、LR 或采样设置。

## Python 评估

评估 CUDA Selector 时，除 YAML 外还需显式允许 Python extension：

```bash
export CARTGS_EXPERIMENTAL_SELECTOR_CUDA=1
export CUDA_HOME=/usr/local/cuda-11.8
export CXX=/usr/bin/g++-9
export TORCH_CUDA_ARCH_LIST=8.6
```

Python 首次使用 CUDA Selector 会通过当前 Python Torch 编译自己的 extension；它与 Native LibTorch 的 ABI 独立。

## 本次更新状态

源码包含 ratio GEMM 修复、fused activation backward、激活 view 复用、Selector CUDA Adam 和 Guard preview。M=219969 的最终隔离测量：forward 约 1.886×、backward 约 1.021×、F+B 约 1.445×；这些不是完整 Mapping 的加速比。

独立完整 renderer 的 1000 步训练在 legacy 自重复中也会漂移；room 单次固定地图质量对照尚未通过全部门槛。因此保留 legacy 默认，由用户自行编译和测试。本次服务器源码更新没有执行编译，也没有替换已有 binary 或模型。
