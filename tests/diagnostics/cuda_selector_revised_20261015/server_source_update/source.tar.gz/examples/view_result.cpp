/**
 * This file is part of Photo-SLAM
 *
 * Copyright (C) 2023-2024 Longwei Li and Hui Cheng, Sun Yat-sen University.
 * Copyright (C) 2023-2024 Huajian Huang and Sai-Kit Yeung, Hong Kong University
 * of Science and Technology.
 *
 * Photo-SLAM is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * Photo-SLAM is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * Photo-SLAM. If not, see <http://www.gnu.org/licenses/>.
 */

#include <torch/torch.h>

#include <filesystem>
#include <iostream>
#include <memory>

#include "include/gaussian_mapper.h"
#include "improvements/selector/selector_options.h"
#include "viewer/imgui_viewer.h"

int main(int argc, char** argv) {
  const auto selector_config_path =
      improvements::selector::extractSelectorConfigPath(argc, argv);
  const auto selector_enabled_override =
      improvements::selector::extractSelectorEnabledOverride(argc, argv);
  if (argc != 4) {
    std::cerr << std::endl
              << "Usage: " << argv[0]
              << " path_to_gaussian_mapping_settings" /*1*/
              << " path_to_camera_parameters"         /*2*/
              << " path_to_result_ply_file"           /*3*/
              << " [--selector-config path]"
              << " [--selector-enabled 0|1]"
              << std::endl;
    return 1;
  }

  // Device
  torch::DeviceType device_type;
  if (torch::cuda::is_available()) {
    std::cout << "CUDA available! Training on GPU." << std::endl;
    device_type = torch::kCUDA;
  } else {
    std::cout << "Training on CPU." << std::endl;
    device_type = torch::kCPU;
  }

  // Create GaussianMapper
  std::filesystem::path gaussian_cfg_path(argv[1]);
  std::filesystem::path camera_path(argv[2]);
  std::filesystem::path result_ply_path(argv[3]);
  std::filesystem::path selector_config_file_path;
  if (selector_config_path) {
    selector_config_file_path = *selector_config_path;
  } else {
    for (auto directory = result_ply_path.parent_path(); !directory.empty();
         directory = directory.parent_path()) {
      const auto candidate = directory / "selector_config.yaml";
      if (std::filesystem::is_regular_file(candidate)) {
        selector_config_file_path = candidate;
        break;
      }
      if (directory == directory.root_path()) break;
    }
    if (selector_config_file_path.empty()) {
      std::cerr << "selector_config.yaml was not found near the result path; "
                   "pass --selector-config explicitly."
                << std::endl;
      return 1;
    }
  }
  std::shared_ptr<GaussianMapper> pGausMapper =
      std::make_shared<GaussianMapper>(nullptr, gaussian_cfg_path,
                                       std::filesystem::path(), 0, device_type,
                                       selector_enabled_override,
                                       selector_config_file_path);
  pGausMapper->loadPly(result_ply_path, camera_path);

  // Create Gaussian Viewer
  std::thread viewer_thd;
  std::shared_ptr<ImGuiViewer> pViewer;
  pViewer = std::make_shared<ImGuiViewer>(nullptr, pGausMapper, false);
  pViewer->run();

  return 0;
}
